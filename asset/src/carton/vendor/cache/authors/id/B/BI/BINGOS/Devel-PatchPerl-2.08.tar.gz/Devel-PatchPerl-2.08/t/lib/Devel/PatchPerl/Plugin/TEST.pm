package Devel::PatchPerl::Plugin::TEST;

use strict;
use warnings;

sub patchperl {
  warn "I AM A TEST PLUGIN\n";
}

qq[1];
