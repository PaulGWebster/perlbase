package LWP::DebugFile;

our $VERSION = '6.76';

# legacy stub

1;
